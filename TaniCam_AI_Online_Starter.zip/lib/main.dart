import 'dart:convert';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String apiBaseUrl = String.fromEnvironment(
  'TANICAM_API_URL',
  defaultValue: 'http://10.0.2.2:8000',
);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TaniCamApp());
}

class TaniCamApp extends StatelessWidget {
  const TaniCamApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF245C3B);
    return MaterialApp(
      title: 'TaniCam AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        scaffoldBackgroundColor: const Color(0xFFF5F7F2),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: green,
          foregroundColor: Colors.white,
        ),
      ),
      home: const CameraHomePage(),
    );
  }
}

class ScanResult {
  final String plant;
  final String finding;
  final String advice;
  final double confidence;
  final bool needsExpertReview;

  const ScanResult({
    required this.plant,
    required this.finding,
    required this.advice,
    required this.confidence,
    required this.needsExpertReview,
  });

  factory ScanResult.fromJson(Map<String, dynamic> json) {
    final rawConfidence = json['confidence'];
    final confidence = rawConfidence is num ? rawConfidence.toDouble() : 0.0;
    return ScanResult(
      plant: (json['plant'] ?? 'Belum dikenali').toString(),
      finding: (json['finding'] ?? 'Belum ada hasil').toString(),
      advice: (json['advice'] ?? 'Ambil foto lebih dekat dan dengan pencahayaan baik.').toString(),
      confidence: confidence.clamp(0.0, 1.0),
      needsExpertReview: json['needs_expert_review'] == true,
    );
  }
}

class CameraHomePage extends StatefulWidget {
  const CameraHomePage({super.key});

  @override
  State<CameraHomePage> createState() => _CameraHomePageState();
}

class _CameraHomePageState extends State<CameraHomePage> {
  CameraController? _cameraController;
  bool _cameraReady = false;
  bool _busy = false;
  String? _error;
  File? _lastPhoto;
  ScanResult? _result;
  final List<_HistoryEntry> _history = [];

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() => _error = 'Kamera tidak ditemukan pada perangkat ini.');
        return;
      }
      final camera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );
      final controller = CameraController(
        camera,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );
      await controller.initialize();
      if (!mounted) {
        await controller.dispose();
        return;
      }
      setState(() {
        _cameraController = controller;
        _cameraReady = true;
        _error = null;
      });
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'Tidak dapat membuka kamera. Periksa izin kamera lalu coba lagi.');
      }
    }
  }

  Future<void> _captureAndAnalyze() async {
    final camera = _cameraController;
    if (camera == null || !camera.value.isInitialized || _busy) return;

    setState(() {
      _busy = true;
      _error = null;
      _result = null;
    });

    try {
      final photo = await camera.takePicture();
      final file = File(photo.path);
      setState(() => _lastPhoto = file);
      final result = await _sendPhoto(file);
      if (!mounted) return;
      setState(() {
        _result = result;
        _history.insert(0, _HistoryEntry(file: file, result: result, time: DateTime.now()));
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Analisis online gagal. Periksa internet dan alamat server, lalu coba lagi.';
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<ScanResult> _sendPhoto(File file) async {
    final uri = Uri.parse('$apiBaseUrl/analyze');
    final request = http.MultipartRequest('POST', uri)
      ..files.add(await http.MultipartFile.fromPath('image', file.path))
      ..headers['Accept'] = 'application/json';

    final streamed = await request.send().timeout(const Duration(seconds: 60));
    final response = await http.Response.fromStream(streamed);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException('Server mengembalikan status ${response.statusCode}');
    }
    final decoded = jsonDecode(response.body);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Format respons server tidak valid');
    }
    return ScanResult.fromJson(decoded);
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final camera = _cameraController;
    return Scaffold(
      appBar: AppBar(
        title: const Text('TaniCam AI'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Row(
              children: [
                Icon(Icons.cloud_done, size: 18, color: Colors.green.shade100),
                const SizedBox(width: 5),
                const Text('Online'),
              ],
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Asisten pertanian melalui kamera',
            style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          const Text('Arahkan kamera ke daun, batang, buah, atau tanda serangan hama.'),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: AspectRatio(
              aspectRatio: camera?.value.isInitialized == true
                  ? camera!.value.aspectRatio
                  : 4 / 3,
              child: _error != null && !_cameraReady
                  ? Container(
                      color: Colors.black12,
                      alignment: Alignment.center,
                      padding: const EdgeInsets.all(20),
                      child: Text(_error!, textAlign: TextAlign.center),
                    )
                  : _cameraReady && camera != null
                      ? CameraPreview(camera)
                      : const ColoredBox(
                          color: Colors.black12,
                          child: Center(child: CircularProgressIndicator()),
                        ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _cameraReady && !_busy ? _captureAndAnalyze : null,
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.camera_alt),
            label: Text(_busy ? 'Menganalisis secara online...' : 'Foto & analisis tanaman'),
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(52),
            ),
          ),
          if (_error != null && _cameraReady) ...[
            const SizedBox(height: 10),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          if (_result != null) ...[
            const SizedBox(height: 20),
            _ResultCard(result: _result!),
          ],
          if (_history.isNotEmpty) ...[
            const SizedBox(height: 24),
            const Text('Riwayat sesi ini', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            for (final item in _history.take(5))
              Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.eco)),
                  title: Text(item.result.finding),
                  subtitle: Text('${item.result.plant} • ${_formatTime(item.time)}'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => showDialog<void>(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text(item.result.finding),
                      content: Text('${item.result.plant}\n\n${item.result.advice}'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Tutup'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
          const SizedBox(height: 18),
          const Text(
            'Catatan: hasil merupakan indikasi awal dari gambar, bukan diagnosis pasti. Untuk keputusan pengendalian hama atau penyakit, lakukan verifikasi lapangan.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime time) =>
      '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
}

class _ResultCard extends StatelessWidget {
  final ScanResult result;
  const _ResultCard({required this.result});

  @override
  Widget build(BuildContext context) {
    final percent = (result.confidence * 100).round();
    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.fact_check, color: Color(0xFF245C3B)),
                SizedBox(width: 8),
                Text('Hasil pemeriksaan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 14),
            _labelValue('Tanaman', result.plant),
            _labelValue('Temuan', result.finding),
            _labelValue('Keyakinan model', '$percent%'),
            const SizedBox(height: 12),
            const Text('Langkah berikutnya', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text(result.advice),
            if (result.needsExpertReview) ...[
              const SizedBox(height: 12),
              const Chip(
                avatar: Icon(Icons.info_outline),
                label: Text('Perlu pemeriksaan lanjutan'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _labelValue(String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(width: 135, child: Text(label, style: const TextStyle(color: Colors.black54))),
            Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600))),
          ],
        ),
      );
}

class _HistoryEntry {
  final File file;
  final ScanResult result;
  final DateTime time;
  const _HistoryEntry({required this.file, required this.result, required this.time});
}
