from io import BytesIO
from PIL import Image, UnidentifiedImageError
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="TaniCam AI API",
    description="Online image analysis API scaffold for TaniCam AI",
    version="0.1.0",
)

# For production, restrict origins to your deployed app/web domain.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

MAX_BYTES = 10 * 1024 * 1024
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}


@app.get("/health")
def health():
    return {"status": "ok", "service": "tanicam-ai-api"}


@app.post("/analyze")
async def analyze(image: UploadFile = File(...)):
    if image.content_type not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=415,
            detail="Format gambar harus JPEG, PNG, atau WebP.",
        )

    raw = await image.read(MAX_BYTES + 1)
    if not raw:
        raise HTTPException(status_code=400, detail="File gambar kosong.")
    if len(raw) > MAX_BYTES:
        raise HTTPException(status_code=413, detail="Ukuran gambar maksimum 10 MB.")

    try:
        picture = Image.open(BytesIO(raw))
        picture.verify()
        # Re-open after verify and check dimensions.
        picture = Image.open(BytesIO(raw))
        width, height = picture.size
        if width < 64 or height < 64:
            raise HTTPException(status_code=400, detail="Resolusi gambar terlalu kecil.")
    except HTTPException:
        raise
    except (UnidentifiedImageError, OSError):
        raise HTTPException(status_code=400, detail="File bukan gambar yang valid.")

    # IMPORTANT:
    # This is a connectivity/API scaffold, NOT a trained diagnosis model.
    # Replace this block with inference from a validated vegetable model,
    # then return its actual class, calibrated confidence, and vetted advice.
    return {
        "plant": "Belum dikenali",
        "finding": "Server menerima gambar; model AI belum dipasang",
        "advice": (
            "Ini adalah mode uji koneksi. Integrasikan model computer vision "
            "terlatih dan tervalidasi sebelum memakai hasil untuk keputusan pertanian."
        ),
        "confidence": 0.0,
        "needs_expert_review": True,
        "image_width": width,
        "image_height": height,
        "model_status": "not_configured",
    }
