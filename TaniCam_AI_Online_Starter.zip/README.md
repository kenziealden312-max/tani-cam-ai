# TaniCam AI — Online Starter

Starter project Flutter + FastAPI. It supports taking a photo in the mobile app and uploading it to an online API. **The API currently validates the image and returns a clearly labeled placeholder. It does not diagnose plant disease until a trained model is integrated.**

## Requirements

- Flutter SDK (stable)
- Android Studio / Xcode for device builds
- Python 3.11+ for the API (Docker is optional)

## 1. Start the API locally

```bash
cd server
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

Test:
- `http://127.0.0.1:8000/health`
- API docs: `http://127.0.0.1:8000/docs`

## 2. Start the Flutter app

From the project root:

```bash
flutter create .
flutter pub get
flutter run --dart-define=TANICAM_API_URL=http://10.0.2.2:8000
```

`10.0.2.2` is the Android emulator's special address for the host computer. For a physical phone, replace it with the computer's LAN IP, for example `http://192.168.1.20:8000`, and ensure both devices share the same network.

For iOS Simulator, use `http://127.0.0.1:8000`. For an actual iPhone, use the computer's LAN IP or a deployed HTTPS endpoint.

## 3. Deploy online

Deploy the `server/` directory to a Python hosting service or your own server. Configure:
`TANICAM_API_URL=https://your-api-domain.example`

Use HTTPS in production. Do not expose a development server directly to the public internet.

## 4. Camera permissions

### Android
Add this to `android/app/src/main/AndroidManifest.xml` inside the manifest element:

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.INTERNET" />
```

For local HTTP development only, set `android:usesCleartextTraffic="true"` on the `<application ...>` element. Remove this for production and use HTTPS.

### iOS
Add to `ios/Runner/Info.plist` inside the top-level `<dict>`:

```xml
<key>NSCameraUsageDescription</key>
<string>TaniCam AI menggunakan kamera untuk memeriksa tanaman.</string>
```

## 5. Important production work

- Train/evaluate a vegetable vision model with labeled field photos.
- Replace the placeholder in `server/main.py` with model inference.
- Validate model results with an agronomist and test across lighting, varieties, and locations.
- Restrict CORS origins, add rate limiting/authentication if needed, and configure retention/deletion for uploaded photos.
- The current history is only in app memory and will reset when the app restarts. Add a local database for persistent history.
